import { User, Plan, Allocation, SystemSettings } from '../types';

// The base URL for your running .NET Web API
const BASE_URL = 'https://localhost:7116/api';

// --- Helper for API calls ---
async function fetchApi(endpoint: string, options: RequestInit = {}) {
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      // Try to get more detailed error info from the response body
      const errorBody = await response.text();
      console.error(`HTTP error! status: ${response.status}`, `Endpoint: ${endpoint}`, `Response: ${errorBody}`);
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    // Handle 'No Content' responses (like for DELETE)
    if (response.status === 204) {
      return null;
    }

    return response.json();
  } catch (error) {
    console.error('Fetch API call failed:', error);
    throw error; // Re-throw the error to be caught by the caller
  }
}

// --- API Service Functions ---

// DTOs for requests that require an actor's ID for auditing
// FIX: Updated DTO to allow role updates and pin changes.
interface UserUpdateRequestDto extends Partial<Omit<User, 'id' | 'pin'>> {
  actorUserId: number;
  newPin?: string;
  currentPin?: string;
}
interface UserCreateRequestDto extends Omit<User, 'id' | 'pin'> {
  actorUserId: number;
}
interface SystemSettingsUpdateDto extends SystemSettings {
  actorUserId: number;
}
interface UpdateHolidaysRequestDto {
  holidayDates: string[];
  actorUserId: number;
}
interface GenerateAllocationsDto {
    actorUserId: number;
}

// Auth
export const apiLogin = (identifier: string, pin: string): Promise<User> => {
  return fetchApi('/TripPlannerApi/login', { // Assuming your controller is named TripPlannerApiController
    method: 'POST',
    body: JSON.stringify({ identifier, pin }),
  });
};

// Users
export const fetchUsers = (): Promise<User[]> => fetchApi('/TripPlannerApi/users');
export const updateUser = (id: number, userData: UserUpdateRequestDto): Promise<void> => fetchApi(`/TripPlannerApi/users/${id}`, { method: 'PUT', body: JSON.stringify(userData) });
export const addUser = (userData: UserCreateRequestDto): Promise<User> => fetchApi('/TripPlannerApi/users', { method: 'POST', body: JSON.stringify(userData) });
export const deleteUser = (id: number): Promise<void> => fetchApi(`/TripPlannerApi/users/${id}`, { method: 'DELETE' });

// Plans
export const submitPlan = (planData: Omit<Plan, 'userName'>): Promise<void> => fetchApi('/TripPlannerApi/plans', { method: 'POST', body: JSON.stringify(planData) });
export const fetchPlans = (year: number, month: number): Promise<Plan[]> => fetchApi(`/TripPlannerApi/plans?year=${year}&month=${month}`);
export const fetchUpdatedUsers = (): Promise<string[]> => fetchApi('/TripPlannerApi/plan-updates');


// Allocations
export const generateAllocations = (dto: GenerateAllocationsDto): Promise<Allocation[]> => fetchApi('/TripPlannerApi/allocations/generate', { method: 'POST', body: JSON.stringify(dto) });
export const fetchAllocations = (): Promise<Allocation[]> => fetchApi('/TripPlannerApi/allocations');

// Settings
export const fetchSystemSettings = (): Promise<SystemSettings> => fetchApi('/TripPlannerApi/settings');
export const updateSystemSettings = (settings: SystemSettingsUpdateDto): Promise<void> => fetchApi('/TripPlannerApi/settings', { method: 'PUT', body: JSON.stringify(settings) });

// Holidays
export const fetchHolidays = (): Promise<string[]> => fetchApi('/TripPlannerApi/holidays');
export const updateHolidays = (dto: UpdateHolidaysRequestDto): Promise<void> => fetchApi('/TripPlannerApi/holidays', { method: 'PUT', body: JSON.stringify(dto) });